$(function(){
				$('#form1phone,#form2phone,#footerFormPhone,#popupFormPhone1,#popupFormPhone2,#popupFormPhone3,#popupFormPhone4,#popupFormPhone5').mask('+7(999)999-99-99');
				$('#feedbackButton').click(function(){
					$('#popup').css('visibility','visible');
					$('#popupBox').css('height','330px');
					$('#popupTitleText').text('Заказ звонка');
					$('#form1').css('display','block');
					$('#popupFormSubmit').text('Позвоните мне').attr('onclick','sendPopupForm(1)');
				});
				$('#slButton.openPrices1Form').click(function(){
					$('#popup').css('visibility','visible');
					$('#popupBox').css('height','330px');
					$('#popupTitleText').text('Заявка на ремонт');
					$('#form2').css('display','block');
					$('#popupFormSubmit').css('width','270px').text('Хочу сделать такой ремонт').attr('onclick','sendPopupForm(2)');
				});
				$('#slButton.openPrices2Form').click(function(){
					$('#popup').css('visibility','visible');
					$('#popupBox').css('height','330px');
					$('#popupTitleText').text('Заявка на ремонт');
					$('#form3').css('display','block');
					$('#popupFormSubmit').css('width','270px').text('Хочу сделать такой ремонт').attr('onclick','sendPopupForm(3)');
				});
				$('#slButton.openPrices3Form').click(function(){
					$('#popup').css('visibility','visible');
					$('#popupBox').css('height','330px');
					$('#popupTitleText').text('Заявка на ремонт');
					$('#form4').css('display','block');
					$('#popupFormSubmit').css('width','270px').text('Хочу сделать такой ремонт').attr('onclick','sendPopupForm(4)');
				});
				$('#slButton.openPrices4Form').click(function(){
					$('#popup').css('visibility','visible');
					$('#popupBox').css('height','330px');
					$('#popupTitleText').text('Заявка на ремонт');
					$('#form5').css('display','block');
					$('#popupFormSubmit').css('width','270px').text('Хочу сделать такой ремонт').attr('onclick','sendPopupForm(5)');
				});
				$('#popupClose').click(function(){
					$('#popup').css('visibility','hidden');
					$('#popupBox').removeAttr('style');
					$('#popupTitleText').text('');
					$('#form1,#form2,#form3,#form4,#form5').css('display','none');
					$('#popupFormSubmit').text('');
					$('#popupFormSubmit').removeAttr('onclick').removeAttr('style');
				});
			});