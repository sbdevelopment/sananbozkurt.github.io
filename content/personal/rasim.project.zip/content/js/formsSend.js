function pageFormSend(id){
	if(id==1){
		var fname = $('#form1name').val();
		var phone = $('#form1phone').val();
		$.ajax({type:'post',url:'/sendForm',
						dataType:"json",cache:!1,
						data:{formid:6,uname:fname,phone:phone},
						beforeSend:function(){
							$("#ajax-status").html("<img src='/content/img/process.gif' align='absmiddle'/>")},
						success:function(a){
							var e=a;
							e&&!e.error?($("#ajax-status").html("").text(e.resultStatus).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300)):
							($("#ajax-status").html("").text(e.error).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300))
						}
					 });
	}
	if(id==2){
		var fname2 = $('#form2name').val();
		var phone2 = $('#form2phone').val();
		$.ajax({type:'post',url:'/sendForm',
						dataType:"json",cache:!1,
						data:{formid:7,uname:fname2,phone:phone2},
						beforeSend:function(){
							$("#ajax-status").html("<img src='/content/img/process.gif' align='absmiddle'/>")},
						success:function(a){
							var e=a;
							e&&!e.error?($("#ajax-status").html("").text(e.resultStatus).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300)):
							($("#ajax-status").html("").text(e.error).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300))
						}
					 });
	}
	if(id==3){
		var fname3 = $('#footerFormName').val();
		var phone3 = $('#footerFormPhone').val();
		$.ajax({type:'post',url:'/sendForm',
						dataType:"json",cache:!1,
						data:{formid:8,uname:fname3,phone:phone3},
						beforeSend:function(){
							$("#ajax-status").html("<img src='/content/img/process.gif' align='absmiddle'/>")},
						success:function(a){
							var e=a;
							e&&!e.error?($("#ajax-status").html("").text(e.resultStatus).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300)):
							($("#ajax-status").html("").text(e.error).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300))
						}
					 });
	}
}
function sendPopupForm(id) {
	if(id==1){
		var fname = $('#popupFormName1').val();
		var phone = $('#popupFormPhone1').val();
		var stime = $('#th').val()+':'+$('#tm').val();
		$.ajax({type:'post',url:'/sendForm',
						dataType:"json",cache:!1,
						data:{formid:1,uname:fname,phone:phone,timesel:stime},
						beforeSend:function(){
							$("#ajax-status").html("<img src='/content/img/process.gif' align='absmiddle'/>")},
						success:function(a){
							var e=a;
							e&&!e.error?($("#ajax-status").html("").text(e.resultStatus).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300)):
							($("#ajax-status").html("").text(e.error).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300))
						}
					 });
	}
	if(id==2){
		var fname2 = $('#popupFormName2').val();
		var phone2 = $('#popupFormPhone2').val();
		$.ajax({type:'post',url:'/sendForm',
						dataType:"json",cache:!1,
						data:{formid:2,uname:fname2,phone:phone2},
						beforeSend:function(){
							$("#ajax-status").html("<img src='/content/img/process.gif' align='absmiddle'/>")},
						success:function(a){
							var e=a;
							e&&!e.error?($("#ajax-status").html("").text(e.resultStatus).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300)):
							($("#ajax-status").html("").text(e.error).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300))
						}
					 });
	}
	if(id==3){
		var fname3 = $('#popupFormName3').val();
		var phone3 = $('#popupFormPhone3').val();
		$.ajax({type:'post',url:'/sendForm',
						dataType:"json",cache:!1,
						data:{formid:3,uname:fname3,phone:phone3},
						beforeSend:function(){
							$("#ajax-status").html("<img src='/content/img/process.gif' align='absmiddle'/>")},
						success:function(a){
							var e=a;
							e&&!e.error?($("#ajax-status").html("").text(e.resultStatus).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300)):
							($("#ajax-status").html("").text(e.error).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300))
						}
					 });
	}
	if(id==4){
		var fname4 = $('#popupFormName4').val();
		var phone4 = $('#popupFormPhone4').val();
		$.ajax({type:'post',url:'/sendForm',
						dataType:"json",cache:!1,
						data:{formid:4,uname:fname4,phone:phone4},
						beforeSend:function(){
							$("#ajax-status").html("<img src='/content/img/process.gif' align='absmiddle'/>")},
						success:function(a){
							var e=a;
							e&&!e.error?($("#ajax-status").html("").text(e.resultStatus).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300)):
							($("#ajax-status").html("").text(e.error).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300))
						}
					 });
	}
	if(id==5){
		var fname5 = $('#popupFormName5').val();
		var phone5 = $('#popupFormPhone5').val();
		$.ajax({type:'post',url:'/sendForm',
						dataType:"json",cache:!1,
						data:{formid:5,uname:fname5,phone:phone5},
						beforeSend:function(){
							$("#ajax-status").html("<img src='/content/img/process.gif' align='absmiddle'/>")},
						success:function(a){
							var e=a;
							e&&!e.error?($("#ajax-status").html("").text(e.resultStatus).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300)):
							($("#ajax-status").html("").text(e.error).animate({"top":"-15px"},300).delay(2500).animate({"top":"-62px"},300))
						}
					 });
	}
}