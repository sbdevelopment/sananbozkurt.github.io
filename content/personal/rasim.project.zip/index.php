<html>
	<head>
		<meta charset="utf-8">
		<meta name="author" content="Sanan Fatullazade">
		<meta name="publisher" content="SananBozkurt.ru">
		<meta name="robots" content="index, follow">
		<meta name="description" content="Профессиональный ремонт и дизайн для Вашей квартиры, дома или офиса под ключ в Нальчике.">
		<meta name="keywords" content="ремонт квартир, в нальчике, нальчик, ремонт офиса, ремонт дома, дизайн интерьера, студия дизайна, студия ремонта, зодчий">
		<link id="favicon" href="/favicon.png" type="image/png" rel="shortcut icon">
		<link id="png16favicon" href="/favicon16.png" type="image/png" rel="icon" sizes="16x16">
		<link id="png32favicon" href="/favicon32.png" type="image/png" rel="icon" sizes="32x32">
		<meta property="og:url" content="http://zodchiy-rem.ru/"/>
		<meta property="og:image" content="/content/img/logo_quadro150.png" />
		<link rel="image_src" href="/content/img/logo_quadro150.png" />
		<link href="/content/css/main.min.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" media="screen and (max-width: 1920px)" href="/content/css/large.min.css" />
		<link rel="stylesheet" media="screen and (max-width: 1680px)" href="/content/css/medium.min.css" />
		<link rel="stylesheet" media="screen and (max-width: 1366px)" href="/content/css/standart.min.css" />
		<link rel="stylesheet" media="screen and (max-width: 1280px)" href="/content/css/small.min.css" />
		<script type="text/javascript" src="/content/js/jquery.min.js"></script>
		<script type="text/javascript" src="/content/js/jquery.maskedinput.min.js"></script>
		<script type="text/javascript" src="/content/js/index.js"></script>
		<script type="text/javascript" src="/content/js/formsSend.js"></script>
		<title>Зодчий - Ремонт и дизайн квартир, домов и офисов в Нальчике.</title>
	</head>
	<body>
		<div align="center">
			<div id="ajax-status"></div>
			<div id="popup" align="center">
				<div id="contentFix">
					<div id="popupBox">
						<div id="popupTitle"><div id="popupTitleText"></div><i id="popupClose">×</i></div>
						<div id="popupContent">
							<div id="form1">
								<div id="popupFormsEl">Ваше имя:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormName1" name="first-name"></div>
								<div id="popupFormsEl">Ваш телефон:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormPhone1" name="phone-number"></div>
								<div id="popupFormsEl">Удобное время звонка:</div>
								<div id="popupFormsSelect">
									<select id="th">
										<option value="09">9</option>
										<option value="10">10</option>
										<option value="11">11</option>
										<option value="12">12</option>
										<option value="13">13</option>
										<option value="14">14</option>
										<option value="15">15</option>
										<option value="16">16</option>
										<option value="17">17</option>
										<option value="18">18</option>
										<option value="19">19</option>
										<option value="20">20</option>
									</select>
									<select id="tm">
										<option value="00">00</option>
										<option value="10">10</option>
										<option value="15">15</option>
										<option value="20">20</option>
										<option value="30">30</option>
										<option value="40">40</option>
										<option value="45">45</option>
										<option value="50">50</option>
									</select>
								</div>
							</div>
							<div id="form2">
								<div id="popupFormsEl">Ваше имя:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormName2" name="first-name"></div>
								<div id="popupFormsEl">Ваш телефон:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormPhone2" name="phone-number"></div>
								<div id="popupFormsEl">Тип ремонта:</div>
								<div id="popupFormsFakeInput">Косметический ремонт</div>
							</div>
							<div id="form3">
								<div id="popupFormsEl">Ваше имя:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormName3" name="first-name"></div>
								<div id="popupFormsEl">Ваш телефон:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormPhone3" name="phone-number"></div>
								<div id="popupFormsEl">Тип ремонта:</div>
								<div id="popupFormsFakeInput">Капитальный ремонт</div>
							</div>
							<div id="form4">
								<div id="popupFormsEl">Ваше имя:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormName4" name="first-name"></div>
								<div id="popupFormsEl">Ваш телефон:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormPhone4" name="phone-number"></div>
								<div id="popupFormsEl">Тип ремонта:</div>
								<div id="popupFormsFakeInput">Премиум</div>
							</div>
							<div id="form5">
								<div id="popupFormsEl">Ваше имя:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormName5" name="first-name"></div>
								<div id="popupFormsEl">Ваш телефон:</div>
								<div id="popupFormsInput"><input type="text" id="popupFormPhone5" name="phone-number"></div>
								<div id="popupFormsEl">Тип ремонта:</div>
								<div id="popupFormsFakeInput">Эксклюзив</div>
							</div>
						</div>
						<div id="popupButton">
							<div id="popupFormSubmit"></div>
						</div>
					</div>
				</div>
			</div>
			<div id="main">
				<div id="splashImg" align="center">
					<div id="contentFix">
						<div id="pageHeader">
							<div id="siteLogo"></div>
							<div id="siteContact">
							<div id="phoneNumber">8-800-000-00-00</div>
							<div id="feedbackButton">заказать звонок</div>
						</div>
						</div>
						<div id="mainTitle">
							ПРОФЕССИОНАЛЬНЫЙ РЕМОНТ И ДИЗАЙН<br/>
							ДЛЯ ВАШЕЙ КВАРТИРЫ, ДОМА ИЛИ ОФИСА<br/>
							ПОД КЛЮЧ В НАЛЬЧИКЕ.
						</div>
						<div id="mainForm">
							<div id="mainFormTitle">
								ОСТАВЬТЕ ЗАЯВКУ НА БЕСПЛАТНЫЙ ВЫЕЗД СПЕЦИАЛИСТА ДЛЯ РАСЧЕТА СТОИМОСТИ РЕМОНТА.
							</div>
							<div id="mainFormInputs">
								<div id="mainFormElem">ВАШЕ ИМЯ:</div>
								<div id="mainFormInput"><input type="text" id="form1name" name="first-name"/></div>
								<div id="mainFormElem">ВАШ ТЕЛЕФОН:</div>
								<div id="mainFormInput"><input type="text" id="form1phone" name="phone-number"/></div>
								<div id="mainFormButton" onclick="pageFormSend(1)">ПРИГЛАСИТЬ СПЕЦИАЛИСТА</div>
							</div>
							<div id="mainFormInfo">Ваши данные надежно защищены.<br/>Конфиденциальность гарантирована.</div>
						</div>
						<div id="circlePointer"></div>
					</div>
				</div>
				<div id="content">
					<div id="aboutServices" align="center">
						<div id="contentFix-small">
							<div id="aboutServTitle">НАШИ ПРЕИМУЩЕСТВА</div>
							<div id="aboutElem">
							<i class="zodchiy zodchiy-1"></i>
							<div id="abotElText">Бесплатная<br/>консультация</div>
						</div>
						<div id="aboutElem">
							<i class="zodchiy zodchiy-2"></i>
							<div id="abotElText">12 лет опыта</div>
						</div>
						<div id="aboutElem">
							<i class="zodchiy zodchiy-3"></i>
							<div id="abotElText">Работа по договору</div>
						</div>
						<div id="aboutElem">
							<i class="zodchiy zodchiy-4"></i>
							<div id="abotElText">Бесплатная уборка</div>
						</div>
						<div id="aboutElem">
							<i class="zodchiy zodchiy-5"></i>
							<div id="abotElText">Сдача объекта<br/>точно в срок</div>
						</div>
						<div id="aboutElem">
							<i class="zodchiy zodchiy-6"></i>
							<div id="abotElText">Привлекательные<br/>цены</div>
						</div>
						<div id="aboutElem">
							<i class="zodchiy zodchiy-7"></i>
							<div id="abotElText">Бесплатный доставка<br/>материалов</div>
						</div>
						<div id="aboutElem">
							<i class="zodchiy zodchiy-8"></i>
							<div id="abotElText">Гарантия качества</div>
						</div>
						</div>
					</div>
					<div id="workStyle" align="center">
						<div id="contentFix">
							<div id="wsTitle">СХЕМА РАБОТЫ</div>
							<div id="wsOne">
								<i class="rombs rombs-1">1</i>
								<div id="wsText" class="one">Заполняте простую форму на сайте.</div>
							</div>
							<div id="wsTwo">
								<i class="rombs rombs-2">2</i>
								<div id="wsText" class="two">К Вам выезжает наш специалист для консультации и оценки объекта.</div>
							</div>
							<div id="wsThree">
								<i class="rombs rombs-3">3</i>
								<div id="wsText" class="three">Выбораете дизайн и мы составим смету и договор.</div>
							</div>
							<div id="wsFour">
								<i class="rombs rombs-4">4</i>
								<div id="wsText" class="four">Качественно производим ремонтные работы в требуемые сроки.</div>
							</div>
							<div id="wsFive">
								<i class="rombs rombs-5">5</i>
								<div id="wsText" class="five">Сдаем объект, оставив Вас  счастливыми.</div>
							</div>
						</div>
					</div>
					<div id="ourPrices">
						<div id="contentFix">
								<div id="pricesTitle">СТОИМОСТЬ УСЛУГ</div>
								<div id="servicesList" class="defaultSelect1">
									<div id="slTitle" class="defaultSelect2">
										<div id="sltStar" class="defaultSelect3"></div>
										<div id="sltText">Косметический ремонт</div>
										<div id="sltPointer" class="defaultSelect4"></div>
									</div>
									<div id="slContent">
										<ul>
											<li>Замена обоев;</li>
											<li>Замена линолиума или ламината;</li>
											<li>Покраска потолков;</li>
											<li>Замена плинтуса;</li>
											<li>Выравнивание откосов;</li>
											<li>Ремонт электропроводки.</li>
										</ul>
									</div>
									<div id="slPrice">от 75 000 руб.</div>
									<div id="slButton" class="defaultSelect5 openPrices1Form">Оставить заявку</div>
								</div>
								<div id="servicesList" class="bestSelect1">
									<div id="slTitle" class="bestSelect2">
										<div id="sltStar" class="bestSelect3"></div>
										<div id="sltText">Капитальный ремонт</div>
										<div id="sltPointer" class="bestSelect4"></div>
										<div id="bestSel"></div>
									</div>
									<div id="slContent">
										<ul>
											<li>Замена обоев;</li>
											<li>Замена линолиума или ламината;</li>
											<li>Покраска потолков;</li>
											<li>Замена плинтуса;</li>
											<li>Выравнивание откосов;</li>
											<li>Ремонт электропроводки.</li>
											<li>Демонтаж стен;</li>
											<li>Монтаж перегородок;</li>
											<li>Частичное выравнивание стен и углов;</li>
											<li>Оклейка обоев и покраска;</li>
											<li>Монтаж подвесных или комбиниванных потолков;</li>
											<li>Выранивание полов;</li>
											<li>Монтаж напольных покрытий и плинусов;</li>
											<li>Облицовка полов и стен плиткой;</li>
											<li>Электромонтаж;</li>
											<li>Сантехнические работы;</li>
											<li>Монтаж систем отопления, обогрева и вентиляции;</li>
											<li>Монтаж  электроприборов и сантехпосуды;</li>
										</ul>
									</div>
									<div id="slPrice">от 199 999 руб.</div>
									<div id="slButton" class="bestSelect5 openPrices2Form">Оставить заявку</div>
								</div>
								<div id="servicesList" class="defaultSelect1">
									<div id="slTitle" class="defaultSelect2">
										<div id="sltStar" class="defaultSelect3"></div>
										<div id="sltText">Премиум</div>
										<div id="sltPointer" class="defaultSelect4"></div>
									</div>
									<div id="slContent">
										<ul>
											<li>Замена обоев;</li>
											<li>Замена линолиума или ламината;</li>
											<li>Покраска потолков;</li>
											<li>Замена плинтуса;</li>
											<li>Выравнивание откосов;</li>
											<li>Ремонт электропроводки.</li>
											<li>Демонтаж стен;</li>
											<li>Монтаж перегородок;</li>
											<li>Частичное выравнивание стен и углов;</li>
											<li>Оклейка обоев и покраска;</li>
											<li>Монтаж подвесных или комбиниванных потолков</li>
											<li>Выранивание полов;</li>
											<li>Монтаж напольных покрытий и плинусов;</li>
											<li>Облицовка полов и стен плиткой;</li>
											<li>Электромонтаж;</li>
											<li>Сантехнические работы;</li>
											<li>Монтаж систем отопления, обогрева и вентиляции;</li>
											<li>Монтаж  электроприборов и сантехпосуды;</li>
											<li>Дизайнерская консультация;</li>
											<li>Раскладка мебели по плану квартиры;</li>
											<li>Нестандартные планировочные решения.</li>
											<li>Декоративная штукатурка;</li>
											<li>Укладка декоративного камня;</li>
										</ul>
									</div>
									<div id="slPrice">от 1 099 999 руб.</div>
									<div id="slButton" class="defaultSelect5 openPrices3Form">Оставить заявку</div>
								</div>
								<div id="servicesList" class="defaultSelect1">
									<div id="slTitle" class="defaultSelect2">
										<div id="sltStar" class="defaultSelect3"></div>
										<div id="sltText">Эксклюзив</div>
										<div id="sltPointer" class="defaultSelect4"></div>
									</div>
									<div id="slContent">
										<ul>
											<li>Замена обоев;</li>
											<li>Замена линолиума или ламината;</li>
											<li>Покраска потолков;</li>
											<li>Замена плинтуса;</li>
											<li>Выравнивание откосов;</li>
											<li>Ремонт электропроводки.</li>
											<li>Демонтаж стен;</li>
											<li>Монтаж перегородок;</li>
											<li>Частичное выравнивание стен и углов;</li>
											<li>Оклейка обоев и покраска;</li>
											<li>Монтаж подвесных или комбиниванных потолков;</li>
											<li>Выранивание полов;</li>
											<li>Монтаж напольных покрытий и плинусов;</li>
											<li>Облицовка полов и стен плиткой;</li>
											<li>Электромонтаж;</li>
											<li>Сантехнические работы;</li>
											<li>Монтаж систем отопления, обогрева и вентиляции;</li>
											<li>Монтаж  электроприборов и сантехпосуды;</li>
											<li>Дизайнерская онсультация;</li>
											<li>Раскладка мебели по плану;</li>
											<li>Нестандартные планировочные решения.</li>
											<li>Декоративная штукатурка;</li>
											<li>Укладка декоративного камня;</li>
											<li>Установка и подключение джакузи, сауны;</li>
											<li>Разработка уникального дизайн-проекта 3D визуализация;</li>
											<li>Тесное сотрудничество дизайнеров и строителей;</li>
											<li>Подбор эксклюзивных материалов;</li>
											<li>Подбор оборудования и мебели;</li>
										</ul>
									</div>
									<div id="slPrice">Цена индивидуальна.</div>
									<div id="slButton" class="defaultSelect5 openPrices4Form">Оставить заявку</div>
								</div>
						</div>
					</div>
					<div id="ifQuestions" align="center">
						<div id="contentFix">
							<div id="questionsTitle">НЕ НАШЛИ ПОДХОДЯЩИЙ ВАРИАНТ? НЕ РАССТРАИВАЙТЕСЬ!<br/>ЗАПОЛНИТЕ ФОРМУ НИЖЕ, И ПОЛУЧИТЕ<br/>БЕСПЛАТНУЮ КОНСУЛЬТАЦИЮ НАШЕГО СПЕЦИАЛИСТА!
</div>
							<div id="questionsFormBox">
								<div id="qfbElem">Ваше имя:</div>
								<div id="qfbInput"><input type="text" id="form2name" name="first-name"/></div>
								<div id="qfbElem">Ваш телефон:</div>
								<div id="qfbInput"><input type="text" id="form2phone" name="phone-number"/></div>
								<div id="questionsFormSubmit" onClick='pageFormSend(2)'>Получить консультацию</div>
							</div>
						</div>
					</div>
					<div id="ourWorks" align="center">
						<div id="contentFix-small" style="height:700px;padding-left:110px">
								<div id="worksTitle" style="margin-left:-80px">НЕКОТОРЫЕ НАШИ РАБОТЫ</div>
								<div id="workList" style="height:560px;">
									<div id="work">
										<div id="workAddress"></div>
										<div id="workImg" class="work1"></div>
										<div id="workInfo"></div>
									</div>
									<div id="work">
										<div id="workAddress"></div>
										<div id="workImg" class="work2"></div>
										<div id="workInfo"></div>
									</div>
									<div id="work">
										<div id="workAddress"></div>
										<div id="workImg" class="work3"></div>
										<div id="workInfo"></div>
									</div>
									<div id="work">
										<div id="workAddress"></div>
										<div id="workImg" class="work4"></div>
										<div id="workInfo"></div>
									</div>
									<div id="work">
										<div id="workAddress"></div>
										<div id="workImg" class="work5"></div>
										<div id="workInfo"></div>
									</div>
									<div id="work">
										<div id="workAddress"></div>
										<div id="workImg" class="work6"></div>
										<div id="workInfo"></div>
									</div>
								</div>
								<div id="viewWorks">Смотреть все работы</div>
						</div>
					</div>
					<div id="getFeedback">
						<div id="contentFix">
							<div id="formFooterBox">
								<div id="formFooterTitle">КАК НАС НАЙТИ?</div>
								<div id="formFooterText">СВЯЖИТЕСЬ С НАМИ ПО ОДНОМУ ИЗ УКАЗАННЫХ НИЖЕ КОНТАКТОВ, ЛИБО ОСТАВЬТЕ СВОИ ДАННЫЕ, И НАШИ СПЕЦИАЛИСТЫ СВЯЖУТСЯ С ВАМИ!</div>
								<div id="formFooterPhone">8-800-000-00-00</div>
								<div id="formFooterMail">mail@zodchiy-rem.ru</div>
								<div id="formFooter">
									<div id="formFooterEl">Ваше имя:</div>
									<div id="formFooterInput"><input type="text" name="first-name" id="footerFormName"/></div>
									<div id="formFooterEl">Ваш телефон:</div>
									<div id="formFooterInput"><input type="text" name="phone-number" id="footerFormPhone"/></div>
									<div id="formFooterSubmit" onClick='pageFormSend(3)'>Перезвоните мне</div>
									<div id="footerGetInform">
										<div id="fgiR2r"></div>
										<div id="fgiText">Возникли вопросы?<br/>Заполните форму справа, и наш специалист ответит на любые Ваши вопросы.</div>
										<div id="fgiL2r"></div>
									</div>
									<div id="footerPointer"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>