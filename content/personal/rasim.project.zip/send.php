<?
header("Content-type: application/json; charset=utf-8");
if(!empty($_POST['formid'])&&!empty($_POST['uname'])&&!empty($_POST['phone'])) {
    $formid=$_POST['formid'];
    $name=$_POST['uname'];
    $phone=$_POST['phone'];
    $errors=false;
    if(!preg_match('/[0-9]/i',$formid)) $errors.='Недопустимые символы в id формы.';
    if(!preg_match('/['.chr(0x7F).'-'.chr(0xff).'a-z]/i',$name)) $errors.='Недопустимые символы в имени пользователя.';
    if(!preg_match('/[-0-9\(\)\+]{10,16}/i',$phone)) $errors.='Введены недопустимые символы в поле ввода номера телефона.';
    if($formid==1){
       $timesel=$_POST['timesel'];
       if(empty($timesel)) $errors.='Время звонка не передано.';
       elseif(!preg_match('/[0-9\:]/i',$timesel)) $errors.='Введенны недопустимые символы в поле время.';
    }
    if(!$errors){
        if($formid==1) $subj='=?UTF-8?B?' . base64_encode('Заявка на обратный звонок из формы в окошке.') . '?=';
        if($formid==2) $subj='=?UTF-8?B?' . base64_encode('Заявка на косметический ремонт.') . '?=';
        if($formid==3) $subj='=?UTF-8?B?' . base64_encode('Заявка на капитальный ремонт.') . '?=';
        if($formid==4) $subj='=?UTF-8?B?' . base64_encode('Заявка на премиум ремонт.') . '?=';
        if($formid==5) $subj='=?UTF-8?B?' . base64_encode('Заявка на эксклюзивный ремонт.') . '?=';
        if($formid==6) $subj='=?UTF-8?B?' . base64_encode('Заявка на приглашение специалиста.') . '?=';
        if($formid==7) $subj='=?UTF-8?B?' . base64_encode('Заявка на консультацию.') . '?=';
        if($formid==8) $subj='=?UTF-8?B?' . base64_encode('Заявка на обратный звонок из формы на странице (внизу).') . '?=';
        $headers='From: =?UTF-8?B?' . base64_encode($name) . '?= <no-reply@zodchiy-rem.ru>'."\n".
            'Content-Type: text/html; charset=\"utf-8\"'."\n";
        if($formid==1){
          $mess='Здравствуйте!<br/>Вам было отправлена заявка на обратный звонок с сайта из формы в окошке. Отправитель - '.$name.' <br/>';
          $mess.='<br/>Желаемое время звонка:<br/>'.$timesel.'<br/>';
        }
        if(preg_match('/[2-5]/i',$formid)){
          $mess='Здравствуйте!<br/>Вам было отправлена заявка на ремонт с сайта. Отправитель - '.$name.' <br/>';
          if($formid==2) $mess.='<br/>Желаемый ремонт: Косметический.<br/>';
          if($formid==3) $mess.='<br/>Желаемый ремонт: Капитальный.<br/>';
          if($formid==4) $mess.='<br/>Желаемый ремонт: Премиум.<br/>';
          if($formid==5) $mess.='<br/>Желаемый ремонт: Эксклюзив.<br/>';
        }
        if($formid==6) $mess='Здравствуйте!<br/>Вам было отправлена заявка на приглашение специалиста. Отправитель - '.$name.' <br/>';
        if($formid==7) $mess='Здравствуйте!<br/>Вам было отправлена заявка на консультацию. Отправитель - '.$name.' <br/>';
        if($formid==8) $mess='Здравствуйте!<br/>Вам было отправлена заявка на обратный звонок. Отправитель - '.$name.' <br/>';
        $mess.='Контактный телефон, указанный в форме: '.$phone.'<br/>';
        if(mail('rasim@zodchiy-rem.ru',$subj,$mess,$headers)) $mess_status='Сообщение успешно отправлено.';
        else $mess_status='Произошла ошибка при отправке письма.';
        echo '{"result":"' . $mess_status . '"}';
    } else echo '{"error":"'.$errors.'"}';
} else echo '{"error":"Заполните все поля формы перед отправкой."}';
?>