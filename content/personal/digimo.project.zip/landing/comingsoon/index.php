<? define('_DIGIMO',1);
include_once $_SERVER['DOCUMENT_ROOT'].'/app/data/params.php';
?>
<!DOCTYPE HTML>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="author" content="DigiRus LTD">
    <meta name="publisher" content="DigiRus LTD, Russia, Moscow">
    <meta name="robots" content="index, follow">
    <meta name="description"
          content="Смотрите легально Ваши любимые сериалы на Digimo TV" lang="ru">
    <meta name="keywords"
          content="сериалы, онлайн, смотреть сериалы онлайн, готэм смотреть онлайн, сверхъестественное смотреть онлайн, касл смотреть онлайн, срела смотреть онлайн, флэш смотреть онлайн, черный список смотреть онлайн, голубая кровь смотреть онлайн, полиция чикаго смотреть онлайн, гримм смотреть онлайн, дневники вампиров смотреть онлайн, константин смотреть онлайн, древние смотреть онлайн, розвуд смотреть онлайн" lang="ru">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="image_src" href="http://digimo.ru/app/data/frontend/view/img/icon150.jpg" />
    <link href="/landing/comingsoon/data/media/css/main.min.css?v=1.0.1" rel="stylesheet" type="text/css">
    <link href="/favicon.png" rel="icon" type="image/png">
    <script type="text/javascript" src="/landing/comingsoon/data/scripts/js/jquery.min.js"></script>
    <!--[if lt IE 9]>
    <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<title>Digimo TV: Смотрите онлайн лучшие сериалы от CW, FOX, NBC и др.</title>
<body>
<div id="request-popup">
    <div id="request-popup-box">
        <div style="position:relative"><b id="popup_close">×</b></div>
        <div id="popup_ajax_answer"></div>
    </div>
</div>
    <div align="center">
        <div id="main">
            <div id="header">
                <div id="fixall">
                    <div id="logo"></div>
                    <div id="share">
                        <div class="pluso" data-background="transparent" data-options="small,square,line,horizontal,counter,theme=04" data-services="vkontakte,twitter,facebook,google" data-user="122925841"></div>
                    </div>
                </div>
            </div>
            <div id="splash">
                <div id="fixall">
                    <div id="s_text">
                        <div id="s_title">Наслаждайся любимыми
                            сериалами на русском языке.</div>
                        <div id="s_subtitle">Смотри <b>онлайн</b> и <b>бесплатно</b>.</div>
                        <div id="mobile_form">
                            <div id="f_input">
                                <input type="text" id="u-email" name="email" placeholder="Ваш е-мейл:"/>
                            </div>
                            <div id="f_button">
                                <p id="orange-button">Получить Доступ к Digimo TV</p>
                            </div>
                            <div id="channels-m"></div>
                        </div>
                        <div id="s_descr">
                            Через полгода состоится бета-запуск Digimo TV.
                            Оставь свой е-мейл, чтобы стать одним из первых,
                            кто получит доступ к новому Digimo TV.
                        </div>
                        <div id="s_small">
                            Предложение имеет временные и количественные ограничения. К бета-запуску
                            можно присоединиться только до 25.02.16. Количество участников не может быть
                            выше, чем 450 пользователей. Каждый пользователь из списка будет определен
                            случайным образом.
                        </div>
                        <div id="copyright-m">© 2015 Digirus Ltd. | <b>18+</b></div>
                    </div>
                    <div id="s_form">
                        <div id="f_input">
                            <input type="text" id="email" name="email" placeholder="Ваш е-мейл:">
                        </div>
                        <div id="f_button">
                            <p id="orange-button">Получить Доступ к Digimo TV</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="logos"></div>
        <div id="text">
            <div id="fixall">
                <div id="text-margin">
                    <div id="text_box1">
                        <div id="box1_title">Не упустите ни одного эпизода</div>
                        <div id="box1_descr">
                            Смотрите свежие эпизоды сразу с выходом их на экранах ТВ, пересматривайте любимые моменты предыдущих сезонов - наслаждайтесь просмотром в 720p и Full HD.
                        </div>
                    </div>
                    <div id="text_box2">
                        <div id="box2_title">Просмотр на мобильных устойствах</div>
                        <div id="box2_descr">
                            Будь то Ваш планшет, смартфон, или ноутбук - смотрите любимые сериалы там, где Вам удобней. Digimo TV разрабатывает для своих зрителей приложения для Android, iOS и Windows 10.
                        </div>
                    </div>
                    <div id="text_box3">
                        <div id="box3_title">Доступен по всей Европе</div>
                        <div id="box3_descr">
                            Следить за выходом новых эпизодов и смореть любимые сериалы Вы сможете даже находясь на каникулах в любой стране Европы - от Великобритании до Азербайджана.
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="footer">
            <div id="fixall" style="border-top: solid 1px #dcdcdc">
                <? include_once INC_HTML.'foot_copy.inc';?>
            </div>
        </div>
    </div>
    <script src="/landing/comingsoon/data/scripts/js/main.js?v=1.0.0" type="text/javascript"></script>
</body>
</html>