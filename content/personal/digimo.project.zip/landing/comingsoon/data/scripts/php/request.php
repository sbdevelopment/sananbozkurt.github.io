<?
define('_DIGIMO',1);
header("Content-type: application/json; charset=utf-8");
include_once $_SERVER['DOCUMENT_ROOT'].'/app/data/params.php';
include_once INC_DB.'connect.inc';
if(isset($_POST['email'])&&!empty($_POST['email'])) {
    $email=$_POST['email'];
    $code=md5(time());
    $errors=false;
    if(!preg_match('/[-0-9a-z_\.]+@[-0-9a-z\.]+\.[a-z]{2,6}/i',$email)) $errors.='Введены недопустимые символы';
    if(!$errors){
        $q="SELECT COUNT(`id`) FROM `digi_users` WHERE `email`='".mysql_real_escape_string($email)."';";
        $cnt=mysql_result(mysql_query($q),0);
        if($cnt==0){
            $insert="INSERT INTO `digi_users` SET
                `email`='".mysql_real_escape_string($email)."',
                `code`='".$code."';";
            if(mysql_query($insert)) {
                $subj='=?UTF-8?B?' . base64_encode('Спасибо!') . '?=';
                $headers='From: =?UTF-8?B?' . base64_encode('Диджимо Россия') . '?= <support@digimo.ru>'."\n".
                    'Content-Type: text/html; charset=\"utf-8\"'."\n";
                $message='<html><body style="background:#eaeaea"><div align="center" style="padding:30px;">'.
                    '<div style="width: 600px; height:60px;padding-top:340px;margin:30px; background: url(http://www.digimo.ru/app/data/frontend/view/img/mail1img.jpg) no-repeat #250221;box-shadow: 0 1px 10px #5d5d5d">'.
                    '<a href="https://twitter.com/digimo_ru"><div style="display: block;float: left;width:120px;height:40px;margin-left:60px;"></div></a>'.
                    '<a href="mailto:support@digimo.ru"><div style="display: block;float: left;width:170px;height:40px;margin-left:20px;cursor:pointer"></div></a>'.
                    '<a href="http://digimo.ru/?utm_source=e_mail&utm_media=mail1img"><div style="display: block;float: left;width:150px;height:40px;margin-left:20px;cursor:pointer"></div></a>'.
                    '</div></div></body></html>';
                mail($email,$subj,$message,$headers);
                $result='Спасибо за подписку!';
                $rnum='1';
            }
            else {
                $result='Ошибка сохранения';
                $rnum='2';
            }
        } else {
            $result='Вы уже оставляли е-мейл';
            $rnum='3';
        }
        echo '{"result":"'.$result.'.","rnum":"'.$rnum.'"}';
    } else echo '{"error":"'.$errors.'."}';
} else echo '{"error":"Вы не ввели е-мейл.'.$_POST['email'].'"}';
?>