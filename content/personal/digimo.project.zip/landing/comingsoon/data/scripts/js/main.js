$(document).load(function(){
    var z=$('#main').height()+$('#logos').height()+$('#text').height();
    var h=$('body').height()-z;
    $("#footer").height(h+'px');
}); 
$(function(){
    $('p#orange-button').click(function(){
        var t=$('#email').val();
        $("#request-popup").css('visibility','visible');
        if(t.length!=0){
            $.ajax({
                type:"post",url:"/sendRequest",dataType:"json",cache:!1,
                data:{"email":t},
                beforeSend:function(){$("#popup_ajax_answer").html("<img src='/app/data/frontend/view/img/process.gif' align='absmiddle'/>")},
                success:function(a){var e=a;e&&!e.error?($("#popup_ajax_answer").html(""),$("#popup_ajax_answer").text(e.result),"1"==e.rnum&&yaCounter33931374.reachGoal("sendRequest")):($("#popup_ajax_answer").html(""),$("#popup_ajax_answer").text(e.error))}
            });
        }else{
            $("#popup_ajax_answer").html("Вы не ввели е-мейл. "+t);
        }
    });
    $("#popup_close").click(function(){
        $("#request-popup").css({visibility:"hidden"}),
        $("#popup_ajax_answer").html("")
    });
});
(function() {
    if (window.pluso)if (typeof window.pluso.start == "function") return;
    if (window.ifpluso==undefined) { window.ifpluso = 1;
        var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
        s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
        s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
        var h=d[g]('body')[0];
        h.appendChild(s);
    }})();