<? define('_DIGIMO',1);
    include_once $_SERVER['DOCUMENT_ROOT'].'/app/data/params.php';
    if(isset($_GET['p'])) {
        switch($_GET['p']):
            case 'about':
                $title='О сервисе';
                break;
            case 'executives':
                $title='Управление';
                break;
            case 'brand':
                $title='Айдентика';
                break;
            default:
                $title='О сервисе';
                break;
        endswitch;
    } else $title='О сервисе';
?>
<!DOCTYPE HTML>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="author" content="DigiRus LTD">
    <meta name="publisher" content="DigiRus LTD, Russia, Moscow">
    <meta name="robots" content="index, follow">
    <meta name="description"
          content="Информация о Диджимо: Проект, команда, корпоративная айдентика" lang="ru">
    <meta name="keywords"
          content="Digimo, Digimo TV онлайн, о проекте, контакты, Диджимо Россия, Диджирус, Диджитал мувис" lang="ru">
    <link href="/app/data/frontend/view/css/corporate.min.css?v=1.0.1" rel="stylesheet" type="text/css">
    <link href="/favicon.png" rel="icon" type="image/png">
    <script type="text/javascript" src="/app/data/frontend/view/js/jquery.min.js"></script>
    <!--[if lt IE 9]>
    <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<title>Диджимо <?=$title?></title>
<body>
<div align="center">
    <div id="head">
        <div id="head_navigation">
            <? include_once INC_HTML.'head.inc';?>
        </div>
        <div id="fixall">
            <div id="head_title">Диджимо Россия.</div>
        </div>
    </div>
    <div id="fixall">
        <div id="content">
            <? if(isset($_GET['p'])) {
                switch($_GET['p']):
                    case 'about':
                        include_once INC_HTML.'corp.about.inc';
                        break;
                    case 'executives':
                        include_once INC_HTML.'corp.executives.inc';
                        break;
                    case 'brand':
                        include_once INC_HTML.'corp.brand.inc';
                        break;
                    default:
                        include_once INC_HTML.'corp.about.inc';
                        break;
                endswitch;
            } else include_once INC_HTML.'corp.about.inc';?>
        </div>
    </div>
    <div id="footer">
        <div id="footer_nav">
            <div id="fixall">
                <? include_once INC_HTML.'foot_nav.inc';?>
            </div>
        </div>
        <div id="fixall">
            <? include_once INC_HTML.'foot_copy.inc';?>
        </div>
    </div>
</div>
</body>
</html>