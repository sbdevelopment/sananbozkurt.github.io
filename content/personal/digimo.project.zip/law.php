<? define('_DIGIMO',1);
include_once $_SERVER['DOCUMENT_ROOT'].'/app/data/params.php';
if(isset($_GET['p'])) {
    switch($_GET['p']):
        case 'privacy':
            $title='Политика конфиденциальности';
            break;
        case 'terms':
            $title='Условия использования';
            break;
        case 'trademarks':
            $title='Уведомление о товарных знаках';
            break;
        default:
            $title='Условия использования';
            break;
    endswitch;
} else $title='Условия использования';
?>
<!DOCTYPE HTML>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="author" content="DigiRus LTD">
    <meta name="publisher" content="DigiRus LTD, Russia, Moscow">
    <meta name="robots" content="index, follow">
    <meta name="description"
          content="Правовая информация Digimo TV - политика конфиденциальности, условия использования и т.д " lang="ru">
    <meta name="keywords"
          content="Digimo, Digimo TV онлайн, о проекте, контакты, Диджимо Россия, Диджирус, Диджитал мувис" lang="ru">
    <link href="/app/data/frontend/view/css/law.css?v=1.0.1" rel="stylesheet" type="text/css">
    <link href="/favicon.png" rel="icon" type="image/png">
    <script type="text/javascript" src="/app/data/frontend/view/js/jquery.min.js"></script>
    <!--[if lt IE 9]>
    <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<title><?=$title;?></title>
<body>
<div align="center">
    <div id="head">
        <div id="head_navigation">
            <? include_once INC_HTML.'head_law.inc';?>
        </div>
        <div id="fixall">
            <div id="head_title">
                <?=$title;?>
            </div>
        </div>
    </div>
    <div id="fixall">
        <div id="content">
            <?
            if(isset($_GET['p'])) {
                switch($_GET['p']):
                    case 'privacy':
                        include_once INC_HTML.'law.privacy.inc';
                        break;
                    case 'terms':
                        include_once INC_HTML.'law.terms.inc';
                        break;
                    case 'trademarks':
                        include_once INC_HTML.'law.tm.inc';
                        break;
                    default:
                        include_once INC_HTML.'law.terms.inc';
                        break;
                endswitch;
            } else include_once INC_HTML.'law.terms.inc'; ?>
        </div>
    </div>
    <div id="footer">
        <div id="footer_nav">
            <div id="fixall">
                <? include_once INC_HTML.'foot_law.inc';?>
            </div>
        </div>
        <div id="fixall">
            <? include_once INC_HTML.'foot_copy.inc';?>
        </div>
    </div>
</div>
</body>
</html>