<? define('_DIGIMO',1);
include_once $_SERVER['DOCUMENT_ROOT'].'/app/data/params.php';?>
<!DOCTYPE HTML>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="author" content="DigiRus LTD">
    <meta name="publisher" content="DigiRus LTD, Russia, Moscow">
    <meta name="robots" content="index, follow">
    <meta name="description"
          content="Войдите на Диджимо и смотрите сериалы онлайн." lang="ru">
    <meta name="keywords"
          content="сериалы, онлайн, смотреть сериалы онлайн, готэм смотреть онлайн, сверхъестественное смотреть онлайн, касл смотреть онлайн, срела смотреть онлайн, флэш смотреть онлайн, черный список смотреть онлайн, голубая кровь смотреть онлайн, полиция чикаго смотреть онлайн, гримм смотреть онлайн, дневники вампиров смотреть онлайн, константин смотреть онлайн, древние смотреть онлайн, розвуд смотреть онлайн" lang="ru">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="image_src" href="http://digimo.ru/app/data/frontend/view/img/icon150.jpg" />
    <link href="/app/data/frontend/view/css/jquery-ui.min.css?v=1.0.0" rel="stylesheet" type="text/css">
    <link href="/app/data/frontend/view/css/main.css?v=1.0.0" rel="stylesheet" type="text/css">
    <link href="/app/data/frontend/view/css/auth.css?v=1.0.0" rel="stylesheet" type="text/css">
    <link href="/favicon.png" rel="icon" type="image/png">
    <script type="text/javascript" src="/app/data/frontend/view/js/jquery.min.js"></script>
    <script type="text/javascript" src="/app/data/frontend/view/js/jquery-ui.min.js"></script>
    <!--[if lt IE 9]>
    <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<title>Digimo TV</title>
<body>
<div align="center">
    <div id="auth-box">
        <div id="auth-digimo-i" onclick="location.href='/lp/comingsoon/'" title="Что такое Диджимо?">i</div>
        <div id="auth-logo"></div>
        <div id="auth-form">
            <div id="auth-inputs">
                <input id="auth-input-login" name="ai-login" type="text"/>
                <input id="auth-input-pass" name="ai-pass" type="password"/>
            </div>
            <div id="auth-dm-but"><b id="auth-key"></b><b id="auth-login">Войти</b></div>
        </div>
        <div id="auth-ajax-answer"></div>
        <div id="auth-social">
            <div id="auth-vk-but"><b id="auth-login">Войти с помощью VK</b><b id="auth-vk"></b></div>
            <div id="auth-tw-but"><b id="auth-login">Войти с помощью Twitter</b><b id="auth-tw"></b></div>
        </div>
    </div>
    <div id="auth-link">
        <a href="/lp/comingsoon/">&copy; DigiRus Ltd, 2015</a>
    </div>
</div>
<script type="text/javascript" src="/app/data/frontend/view/js/main.js"></script>
</body>
</html>
