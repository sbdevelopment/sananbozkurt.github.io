<? defined('_DIGIMO')  or die('Forbidden');
define('ROOT_DIR',$_SERVER['DOCUMENT_ROOT'].'/');
define('INC_HTML',ROOT_DIR.'app/data/frontend/view/html/');
define('INC_DB',ROOT_DIR.'app/data/backend/controllers/db/');
define('INC_CTRLS',ROOT_DIR.'app/data/backend/controllers/');
define('INC_MODELS',ROOT_DIR.'app/data/backend/models/');