<?  define('_DIGIMO',1);
    header("Content-type: application/json; charset=utf-8");
    include_once $_SERVER['DOCUMENT_ROOT'].'/app/data/params.php';
    include_once INC_DB.'connect.inc';
    if(!empty($_POST['u'])&&!empty($_POST['k'])){
        echo '{"error":"Форма авторизации отключена."}';
    }else echo '{"error":"Не переданы логин и/или пароль."}';
?>

