$(document).ready(function(){
    $("#auth-box").animate({"opacity":1},3050);
    $("#auth-link").animate({"opacity":1},3050);
});
$(function(){
    $("#auth-dm-but").click(function(){
        var close='<script'+' type="text/javascript">$(function(){$("#close").click(function(){$("#auth-ajax-answer").css({"background":"#fff","color":"#150015"}).html("");});});<'+'/'+'script>',
            login=$('#auth-input-login').val(),
            password=$('#auth-input-pass').val();
        if(login.length!=0 && password.length!=0){
            $.ajax({
                type:"post",url:"/login",dataType:"json",cache:!1,
                data:{"u":login,"k":password},
                beforeSend:function(){$("#auth-ajax-answer").html("<img src='/app/data/frontend/view/img/process.gif' align='absmiddle'/>")},
                success:function(a){var e=a;e&&!e.error?(location.href='/dashboard'):($("#auth-ajax-answer").html("<div id='auth-answer-text'>"+e.error+"</div><p id='close'>×</p>"+close),$("#auth-ajax-answer").css({"background":"#FFC8C5","color":"#780000"}),$("#close").css({"color":"#780000"}))}
            });
        }else{
            $("#auth-ajax-answer").css({"background":"#FFC8C5","color":"#780000"}).html("<div id='auth-answer-text'>Вы не ввели логин и пароль</dov><p id='close'>×</p>"+close);
            $("#close").css({"color":"#780000"});
        }
    });
    $("#auth-vk-but").click(function(){
        var close='<script'+' type="text/javascript">$(function(){$("#close").click(function(){$("#auth-ajax-answer").css({"background":"#fff","color":"#150015"}).html("");});});<'+'/'+'script>';
        $("#auth-ajax-answer").css({"background":"#FFC8C5","color":"#780000"}).html("<div id='auth-answer-text'>Авторизация через ВК отключена</dov><p id='close'>×</p>"+close);
        $("#close").css({"color":"#780000"});
    });
    $("#auth-tw-but").click(function(){
        var close='<script'+' type="text/javascript">$(function(){$("#close").click(function(){$("#auth-ajax-answer").css({"background":"#fff","color":"#150015"}).html("");});});<'+'/'+'script>';
        $("#auth-ajax-answer").css({"background":"#FFC8C5","color":"#780000"}).html("<div id='auth-answer-text'>Авторизация через Твиттер отключена</dov><p id='close'>×</p>"+close);
        $("#close").css({"color":"#780000"});
    });
    $(document).tooltip({
        track: true,
        position: {
            my: "center bottom-20",
            at: "center bottom",
            using: function( position, feedback ) {
                $( this ).css( position );
                $( "<div>" )
                    .addClass( "arrow" )
                    .addClass( feedback.vertical )
                    .addClass( feedback.horizontal )
                    .appendTo( this );
            }
        }
    });
})